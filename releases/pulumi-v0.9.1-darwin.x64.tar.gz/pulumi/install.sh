#!/bin/bash
set -o nounset -o errexit -o pipefail
SCRIPT_DIR="$( cd "$( dirname "$0" )" && pwd )"

HAVE_YARN=0
HAVE_NPM=0
NEED_SUDO_FOR_NPM=0

INSTALL_LOG=${SCRIPT_DIR}/install.log
INSTALL_DIR=/usr/local/pulumi

function on_exit() {
    if [ "$?" -ne 0 ]; then
        >&2 echo "error: There was a problem during installation, please join the #install channel"
        >&2 echo "on pulumi-customer.slack.com for help. We may need the install log file which"
        >&2 echo "can be found at: ${INSTALL_LOG}"
    fi
}

function install_pkg() {
    pushd "${INSTALL_DIR}/node_modules/$1" > /dev/null
    echo "Installing Pulumi package $1..."

    if [ "$HAVE_YARN" -eq 1 ]; then
        echo "running yarn link for module $1" >> "${INSTALL_LOG}"
        (yarn unlink || true ; yarn link) >> "${INSTALL_LOG}" 2>&1
    fi

    if [ "$HAVE_NPM" -eq 1 ]; then
        echo "running npm link for module $1" >> "${INSTALL_LOG}"

        if [ "$NEED_SUDO_FOR_NPM" -eq 1 ]; then
            (sudo npm unlink || true ; sudo npm link) >> "${INSTALL_LOG}" 2>&1
        else
            (npm unlink || true ; npm link) >> "${INSTALL_LOG}" 2>&1
        fi
    fi
    popd > /dev/null
}

if command -v yarn >/dev/null 2>&1 ; then
    HAVE_YARN=1
fi

if command -v npm >/dev/null 2>&1 ; then
    HAVE_NPM=1
fi

if [ "$HAVE_YARN" -eq 0 ] && [ "$HAVE_NPM" -eq 0 ]; then
    >&2 echo "error: Please install yarn or npm (and add them to your \$PATH) before running this script."
    exit 1
fi

if [ "$(node -p process.version)" != "v6.10.2" ]; then
    >&2 echo "error: Pulumi requires NodeJS v6.10.2 but you have $(node -p process.version) installed"
    >&2 echo "       please see https://docs.pulumi.com/install/ for more information."
    exit 1
fi

if [ $(id -u) -eq 0 ]; then
    >&2 echo "error: install.sh should not be run as root, please run it as a regular user."
    exit 1
fi

trap on_exit EXIT

[ ! -e "${INSTALL_LOG}" ] || rm "${INSTALL_LOG}"

echo "Installing Pulumi to ${INSTALL_DIR}" | tee -a "${INSTALL_LOG}"
echo "HAVE_NPM=${HAVE_NPM}" >> "${INSTALL_LOG}"
echo "HAVE_YARN=${HAVE_YARN}" >> "${INSTALL_LOG}"
echo "NEED_SUDO_FOR_NPM=${NEED_SUDO_FOR_NPM}" >> "${INSTALL_LOG}"

if [ ! -w $(dirname "${INSTALL_DIR}") ]; then
    echo "Creating ${INSTALL_DIR} as root" >> "${INSTALL_LOG}"

    echo "It looks like you don't have write access to /usr/local, this script will sudo"
    echo "to create ${INSTALL_DIR}, so you may be prompted for your password."

    sudo sh -c "[ ! -e \"${INSTALL_DIR}\" ] || rm -rf \"${INSTALL_DIR}\" ; mkdir \"${INSTALL_DIR}\" ; chown -R $(id -u):$(id -g) \"${INSTALL_DIR}\""
else
    echo "Creating ${INSTALL_DIR} as regular user" >> "${INSTALL_LOG}"

    [ ! -e "${INSTALL_DIR}" ] || rm -rf "${INSTALL_DIR}"
    mkdir "${INSTALL_DIR}"
fi

echo "Copying bin to ${INSTALL_DIR}" >> "${INSTALL_LOG}"
cp -r "${SCRIPT_DIR}/bin" "${INSTALL_DIR}/"

echo "Copying node_modules to ${INSTALL_DIR}" >> "${INSTALL_LOG}"
cp -r "${SCRIPT_DIR}/node_modules" "${INSTALL_DIR}/"

# npm link will try to create stuff in the global node_modules folder, which may not be writable
# by a standard user. Check to see if we can write to it and if not, make a note of that so when
# we install packages, we can sudo.
if [ ! -w $(npm prefix -g)/lib/node_modules ]; then
    NEED_SUDO_FOR_NPM=1

    if [ ${HAVE_NPM} -eq 1 ]; then
       echo "It looks like you don't have write access to $(npm prefix -g)/lib/node_modules"
       echo "which is where 'npm link' registers modules. This script will sudo before running"
       echo "'npm link', so you may be prompted for your password."
       echo ""
    fi
fi

install_pkg "pulumi"
install_pkg "@pulumi/aws"
install_pkg "@pulumi/cloud"
install_pkg "@pulumi/cloud-aws"

echo "Pulumi is now installed, please add ${INSTALL_DIR}/bin to your \$PATH"
